# START HERE

这是 2026-08-21 生成的跨会话工程交接包。

建议新会话上传两个压缩包：

1. 本包：`AFLplusplus_new_chat_handoff_20260821.zip`
   - 上下文
   - 最新审计
   - 机器可读证据
   - 项目背景
   - 新会话 Prompt

2. 用户 WSL 上执行 `05_user_action/collect_repo_files.sh` 生成的源码包
   - 精确来自 53cb267 committed tree
   - 包含 release→content checkpoint 的变更文件
   - 包含 production harness / Level-C launchers / target configs / tests / scanner
   - 自动收集下一阶段 feedback-loop 候选源码

然后把 `01_context/NEW_CHAT_PROMPT.txt` 作为新会话首条消息。

注意：
- 本交接包没有伪造任何无法直接读取的 WSL 源码。
- 当前功能开发权威基线是 53cb267，不是 dirty public-release 工作区。
- `/tmp` 历史 intermediate worktree 已由用户另外完成归档和一致性验证，不需要放进新会话才能继续功能开发。
