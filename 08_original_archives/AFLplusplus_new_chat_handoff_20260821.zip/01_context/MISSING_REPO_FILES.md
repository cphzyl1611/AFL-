# 当前压缩包中无法直接嵌入的仓库源码

原因：这些文件位于用户自己的 WSL/Git worktree 或 ChatGPT File Library 引用中，不是当前可直接复制到 /mnt/data 的本地文件。不能根据片段重新拼接伪造完整源码。

新会话若要直接进入开发，建议用户额外上传由 `05_user_action/collect_repo_files.sh` 生成的源码 zip。

最小核心源码清单：

- nv_http_harness.py
- scripts/run_alfresco_levelc_metadata.py
- scripts/run_alfresco_levelc_content.py
- targets/alfresco_metadata_update.json
- targets/alfresco_content_update.json
- tests/test_alfresco_levelc_metadata.py
- tests/test_alfresco_levelc_content.py
- tests/test_v071_platform_chains.py
- scripts/secret_scan.py
- tests/test_secret_scan.py
- docs/review/secret_scanner.md
- tests/test_flowable_credential_contract.py
- flowable_query.json

下一阶段反馈闭环还必须带上实际实现文件。收集脚本会从精确 checkpoint `53cb267...`：
1. 收集 c6817ce..53cb267 所有 committed delta；
2. 收集上述核心文件；
3. 通过 grep 收集包含 NV_MAB / UCB / ss_cov_cnt / reward / security-state / stats 等关键词的 committed text files；
4. 补充常见 AFL++ 核心实现文件（若存在）：
   - include/afl-fuzz.h
   - src/afl-fuzz.c
   - src/afl-fuzz-queue.c
   - src/afl-fuzz-one.c
   - src/afl-fuzz-run.c
   - src/afl-fuzz-stats.c

不要上传：
- 运行时 credential 文件
- Authorization header
- /tmp 运行时 rendered target config
- 含真实账号口令的 shell history
