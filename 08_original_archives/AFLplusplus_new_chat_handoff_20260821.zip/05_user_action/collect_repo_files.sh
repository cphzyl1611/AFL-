#!/usr/bin/env bash
set -euo pipefail

# Read-only committed-source collector for the next ChatGPT conversation.
# It does NOT modify refs, index, or worktree files.

REPO="${REPO:-/home/dministrator/AFLplusplus-alfresco-levelc-content}"
BASE="${BASE:-53cb2679de33d6b7737c1fa9cf8a39ef9e8b0aa1}"
RELEASE="${RELEASE:-c6817ce46b0120da95ba55869b6b298e18e4cf8b}"
STAMP="$(date +%Y%m%d-%H%M%S)"
ROOT="/home/dministrator/AFLplusplus-newchat-source-${STAMP}"
OUT="/home/dministrator/AFLplusplus-newchat-source-${STAMP}.zip"

echo "=== VERIFY SOURCE REPO ==="
echo "repo=$REPO"
git -C "$REPO" rev-parse --is-inside-work-tree
ACTUAL="$(git -C "$REPO" rev-parse "${BASE}^{commit}")"
echo "base=$ACTUAL"
if [ "$ACTUAL" != "$BASE" ]; then
  echo "ERROR: BASE does not resolve to expected commit" >&2
  exit 1
fi

mkdir -p "$ROOT/repo"

# Provenance
git -C "$REPO" show --no-patch --format=fuller "$BASE" > "$ROOT/COMMIT.txt"
git -C "$REPO" diff --name-status "$RELEASE..$BASE" > "$ROOT/DELTA_NAME_STATUS.txt"
git -C "$REPO" diff --stat "$RELEASE..$BASE" > "$ROOT/DELTA_STAT.txt"
git -C "$REPO" log --oneline --decorate "$RELEASE..$BASE" > "$ROOT/LINEAGE.txt"

# Core paths required for the handoff.
cat > "$ROOT/core_paths.txt" <<'EOF'
nv_http_harness.py
scripts/run_alfresco_levelc_metadata.py
scripts/run_alfresco_levelc_content.py
targets/alfresco_metadata_update.json
targets/alfresco_content_update.json
tests/test_alfresco_levelc_metadata.py
tests/test_alfresco_levelc_content.py
tests/test_v071_platform_chains.py
scripts/secret_scan.py
tests/test_secret_scan.py
docs/review/secret_scanner.md
tests/test_flowable_credential_contract.py
flowable_query.json
include/afl-fuzz.h
src/afl-fuzz.c
src/afl-fuzz-queue.c
src/afl-fuzz-one.c
src/afl-fuzz-run.c
src/afl-fuzz-stats.c
EOF

# Every path changed between formal release and latest verified checkpoint.
git -C "$REPO" diff --name-only "$RELEASE..$BASE" > "$ROOT/delta_paths.txt"

# Feedback-loop candidate inventory from the exact committed tree.
PATTERN='NV_MAB|NC_MAB|UCB|ss_cov_cnt|ss_selected_cnt|ss_prob|mean_reward|reward|security.?state|state.?coverage|fuzzer_stats|eval_report|summary\.csv|nv_valid|nv_invalid|recover_ms|recovered'
git -C "$REPO" grep -l -E "$PATTERN" "$BASE" -- > "$ROOT/feedback_candidate_paths.txt" || true
git -C "$REPO" grep -n -E "$PATTERN" "$BASE" -- > "$ROOT/feedback_grep.txt" || true

cat "$ROOT/core_paths.txt" \
    "$ROOT/delta_paths.txt" \
    "$ROOT/feedback_candidate_paths.txt" |
  sed '/^[[:space:]]*$/d' |
  sort -u > "$ROOT/all_requested_paths.txt"

MISSING="$ROOT/missing_paths.txt"
: > "$MISSING"

while IFS= read -r p; do
  [ -n "$p" ] || continue
  if git -C "$REPO" cat-file -e "$BASE:$p" 2>/dev/null; then
    mkdir -p "$ROOT/repo/$(dirname "$p")"
    git -C "$REPO" show "$BASE:$p" > "$ROOT/repo/$p"
  else
    echo "$p" >> "$MISSING"
  fi
done < "$ROOT/all_requested_paths.txt"

# Manifest
(
  cd "$ROOT"
  find . -type f ! -name SHA256SUMS.txt -print0 |
    sort -z |
    xargs -0 sha256sum > SHA256SUMS.txt
)

# Zip using Python so the script does not depend on the zip package.
python3 - "$ROOT" "$OUT" <<'PY'
from pathlib import Path
import sys, zipfile
root = Path(sys.argv[1])
out = Path(sys.argv[2])
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob("*")):
        if p.is_file():
            z.write(p, p.relative_to(root))
print(out)
PY

echo
echo "=== DONE ==="
echo "SOURCE_ZIP=$OUT"
echo "files=$(find "$ROOT/repo" -type f | wc -l)"
echo "missing=$(wc -l < "$MISSING")"
echo
echo "Upload this zip together with the ChatGPT handoff zip."
